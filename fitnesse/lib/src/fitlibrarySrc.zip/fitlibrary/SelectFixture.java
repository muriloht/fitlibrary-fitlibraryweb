package fitlibrary;

public class SelectFixture extends DoFixture {
	// Functionality is now handled by DoFlow/ScopeStack
}
