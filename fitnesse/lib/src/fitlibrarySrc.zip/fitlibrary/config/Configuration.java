package fitlibrary.config;

public interface Configuration {
	boolean keepingUniCode();
}
