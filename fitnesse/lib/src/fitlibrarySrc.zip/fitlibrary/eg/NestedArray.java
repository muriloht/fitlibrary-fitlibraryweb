/*
 * Copyright (c) 2006 Rick Mugridge, www.RimuResearch.com
 * Released under the terms of the GNU General Public License version 2 or later.
*/
package fitlibrary.eg;

import fitlibrary.DoFixture;

public class NestedArray extends DoFixture {
	public int[] arrayCommaArray(int[] array) {
		return array;
	}
}
