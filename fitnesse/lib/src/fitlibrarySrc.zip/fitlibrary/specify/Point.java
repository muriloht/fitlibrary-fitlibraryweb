/*
 * Copyright (c) 2006 Rick Mugridge, www.RimuResearch.com
 * Released under the terms of the GNU General Public License version 2 or later.
*/
package fitlibrary.specify;

public class Point {
	public int x, y;

	public Point() {
		this(0,0);
	}
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public void move(@SuppressWarnings("hiding") int x, @SuppressWarnings("hiding") int y) {
		this.x = x;
		this.y = y;
	}
	public void setX(int x) {
		this.x = x;
	}
	public void setY(int y) {
		this.y = y;
	}
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Point))
			return false;
		Point other = (Point) object;
		return x == other.x && y == other.y;
	}
}
