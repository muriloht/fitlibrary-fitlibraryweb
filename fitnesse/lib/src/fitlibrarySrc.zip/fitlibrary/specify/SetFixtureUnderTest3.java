/*
 * Copyright (c) 2006 Rick Mugridge, www.RimuResearch.com
 * Released under the terms of the GNU General Public License version 2 or later.
*/
package fitlibrary.specify;

import java.util.ArrayList;

public class SetFixtureUnderTest3 extends fitlibrary.SetFixture {
	@SuppressWarnings("unchecked")
	public SetFixtureUnderTest3() throws Exception {
		super(new ArrayList());
	}
}
