package fitlibrary.specify;

import fitlibrary.PrimitiveArrayFixture;

public class PrimitiveArrayFixtureUnderTest extends PrimitiveArrayFixture {
	public PrimitiveArrayFixtureUnderTest() {
		super(new int[]{1,2,3});
	}
}
