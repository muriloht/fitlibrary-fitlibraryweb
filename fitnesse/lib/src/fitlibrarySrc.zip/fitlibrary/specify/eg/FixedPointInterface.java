package fitlibrary.specify.eg;

public interface FixedPointInterface {
	int getX();
}
