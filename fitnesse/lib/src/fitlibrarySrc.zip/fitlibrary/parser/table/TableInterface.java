/*
 * Copyright (c) 2006 Rick Mugridge, www.RimuResearch.com
 * Released under the terms of the GNU General Public License version 2 or later.
*/
package fitlibrary.parser.table;

/**
 * 
 */
public interface TableInterface {
	    public Table toTable();
//	    public static boolean equals(Object o1, Object o2);
//	    public static Table parseTable(Parse p);
}
