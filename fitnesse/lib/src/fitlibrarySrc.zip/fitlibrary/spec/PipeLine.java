package fitlibrary.spec;

public interface PipeLine {
	boolean match(String actual2, String expected2);
}
